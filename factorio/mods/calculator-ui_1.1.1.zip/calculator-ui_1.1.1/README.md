# Calculator UI

Calculator UI is a Factorio mod which adds a calculator to the Factorio game with the goal to have a little bit of usability behind it.

## Based on
The 4-Function Calculator found in the [Max Rate Calculator](https://mods.factorio.com/mod/MaxRateCalculator) mod by [Theanderblast](https://mods.factorio.com/user/theanderblast).

## Features
- List of recent calculations
- Use of parentheses in the equation
- Rounding of numbers (number of decimal places can be set in the settings)
- Copy a recent calculation into the current calculation (by shift+left-click on the equation you want to copy)
- A nifty little easter egg ;-)
- Use of some advanced function and constants of the Lua [math-lib](http://lua-users.org/wiki/MathLibraryTutorial) (without math.) -> e.g. "pi" instead of "math.pi".
- Shortcut for opening the calculator and automatically focus on the input (Default: Ctrl+Shift+C) 
- When setting "Clear equation on calculation" is set, it allows you to "calculate further", it takes the previous result and applies the new equation to it

## Installation
Well ... ehm ... search for the mod ingame and install it :-)

## Usage
Press the 3 little dots on the shortcuts UI of Factorio to select the "Calculator". Afterwards you can click on the calculator symbol to open it.

## Changelog
see separate [changelog](changelog.txt)

## License
[MIT](https://choosealicense.com/licenses/mit/)