data:extend({
	{
		type = "custom-input",
		name = "calcui_hotkey",
		key_sequence = "CONTROL + SHIFT + C",
		consuming = "none"
	}
})