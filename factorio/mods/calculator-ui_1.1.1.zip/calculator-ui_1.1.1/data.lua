--data.lua

require("calcui-prototypes")
require("calcui-styles")
require("calcui-hotkey")